extends Node

signal server_started
signal server_start_failed(error: int)
signal client_connected
signal client_connection_failed
signal client_disconnected

const PORT: int = 42069
const MAX_PLAYERS: int = 8

var peer: ENetMultiplayerPeer


func start_server() -> void:
	peer = ENetMultiplayerPeer.new()

	var error := peer.create_server(PORT, MAX_PLAYERS)

	if error != OK:
		print("ERROR AL CREAR SERVIDOR: ", error)
		server_start_failed.emit(error)
		return

	multiplayer.multiplayer_peer = peer

	print("SERVIDOR INICIADO")
	print("PUERTO: ", PORT)
	print("IP(s) PARA EL CLIENTE:")
	for ip in IP.get_local_addresses():
		# Filtra direcciones IPv4 de LAN reales, descartando localhost y IPv6
		if ip.count(".") == 3 and not ip.begins_with("127."):
			print(" - ", ip)

	server_started.emit()


func start_client(ip: String) -> void:
	peer = ENetMultiplayerPeer.new()

	var error := peer.create_client(ip, PORT)

	if error != OK:
		print("ERROR AL CREAR CLIENTE: ", error)
		return

	multiplayer.multiplayer_peer = peer

	if not multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.connect(_on_connected_to_server)
		multiplayer.connection_failed.connect(_on_connection_failed)
		multiplayer.server_disconnected.connect(_on_server_disconnected)

	print("CONECTANDO A: ", ip, ":", PORT)


func _on_connected_to_server() -> void:
	print("CONECTADO AL SERVIDOR")
	client_connected.emit()


func _on_connection_failed() -> void:
	print("FALLO LA CONEXION")
	client_connection_failed.emit()


func _on_server_disconnected() -> void:
	print("SERVIDOR DESCONECTADO")
	client_disconnected.emit()
