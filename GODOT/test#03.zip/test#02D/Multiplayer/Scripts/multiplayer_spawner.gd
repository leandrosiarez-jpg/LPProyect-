extends MultiplayerSpawner

@export var network_player: PackedScene


func _ready() -> void:
	spawn_function = _do_spawn

	multiplayer.peer_connected.connect(_on_peer_connected)
	HighLevelNetworkHandler.server_started.connect(_on_server_started)


func _on_server_started() -> void:
	# El host tambien necesita su propio jugador; peer_connected
	# solo se dispara para los clientes que se conectan despues.
	if multiplayer.is_server():
		spawn(multiplayer.get_unique_id())


func _on_peer_connected(id: int) -> void:
	if multiplayer.is_server():
		spawn(id)


# spawn_function: el MultiplayerSpawner llama a esto SOLO en el servidor,
# crea el nodo, y se encarga el mismo de hacer add_child de forma segura
# y de replicarlo en todos los clientes. No hay que llamar add_child a mano.
func _do_spawn(id: int) -> Node:
	var player: Node = network_player.instantiate()
	player.name = str(id)
	return player
