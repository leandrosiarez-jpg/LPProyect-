extends Control

@onready var ip_input: LineEdit = $VBoxContainer/IPInput
@onready var status_Button: Button = $VBoxContainer/Cliente


func _on_server_pressed() -> void:
	_reset_peer()
	HighLevelNetworkHandler.start_server()


func _on_cliente_pressed() -> void:
	var ip := ip_input.text.strip_edges()

	if ip.is_empty():
		_set_status("Escribi la IP del host antes de conectar.")
		return

	if not _is_valid_ipv4(ip):
		_set_status("IP invalida: %s" % ip)
		return

	_reset_peer()
	HighLevelNetworkHandler.start_client(ip)
	_set_status("Conectando a %s..." % ip)


# Limpia cualquier conexion/peer previo antes de crear uno nuevo,
# para que un intento anterior (server o cliente) no interfiera.
func _reset_peer() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null


func _is_valid_ipv4(ip: String) -> bool:
	var parts := ip.split(".")
	if parts.size() != 4:
		return false
	for part in parts:
		if not part.is_valid_int():
			return false
		var n := int(part)
		if n < 0 or n > 255:
			return false
	return true


func _set_status(text: String) -> void:
	if status_Button:
		status_Button.text = text
