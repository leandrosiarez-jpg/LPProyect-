extends Control

@export var player_list_container: VBoxContainer
@export var player_prefab: PackedScene

var players_ui: Dictionary = {}
var is_ready: bool = false

func _ready():
	# Esperar un frame para que los autoloads estén listos
	await get_tree().process_frame
	
	if not NetworkManager or not GameState:
		print("❌ Autoloads no disponibles")
		return
	
	# Conectar señales
	NetworkManager.player_connected.connect(_on_player_connected)
	NetworkManager.player_disconnected.connect(_on_player_disconnected)
	GameState.players_updated.connect(_update_lobby)
	
	# CONSTRUIR LA UI AUTOMÁTICAMENTE
	_build_ui_if_needed()
	
	# Actualizar lobby
	_update_lobby()
	
	print("✅ Lobby listo!")

func _build_ui_if_needed():
	# Verificar si ya existe un VBoxContainer principal
	var main_container = null
	for child in get_children():
		if child is VBoxContainer:
			main_container = child
			break
	
	# Si no hay VBoxContainer, crearlo
	if not main_container:
		main_container = VBoxContainer.new()
		main_container.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
		main_container.size = Vector2(400, 500)
		add_child(main_container)
		print("✅ Creado VBoxContainer principal")
	
	# Buscar o crear player_list_container
	if not player_list_container:
		for child in main_container.get_children():
			if child is VBoxContainer and child.name == "player_list_container":
				player_list_container = child
				break
		
		# Si no existe, crearlo
		if not player_list_container:
			player_list_container = VBoxContainer.new()
			player_list_container.name = "player_list_container"
			main_container.add_child(player_list_container)
			print("✅ Creado player_list_container")
	
	# Buscar o crear botones
	var ready_btn = _find_or_create_button(main_container, "ReadyButton", "❌ No listo")
	var start_btn = _find_or_create_button(main_container, "StartButton", "🚀 Iniciar")
	var exit_btn = _find_or_create_button(main_container, "ExitButton", "🚪 Salir")
	var status_label = _find_or_create_label(main_container, "StatusLabel", "⏳ Esperando jugadores...")
	
	# Conectar botones
	if ready_btn and not ready_btn.pressed.is_connected(_on_ready_button_pressed):
		ready_btn.pressed.connect(_on_ready_button_pressed)
	
	if start_btn and not start_btn.pressed.is_connected(_on_start_button_pressed):
		start_btn.pressed.connect(_on_start_button_pressed)
		start_btn.visible = NetworkManager.is_host
	
	if exit_btn and not exit_btn.pressed.is_connected(_on_exit_button_pressed):
		exit_btn.pressed.connect(_on_exit_button_pressed)

func _find_or_create_button(parent: Node, name: String, text: String):
	# Buscar por nombre
	for child in parent.get_children():
		if child.name == name:
			return child
	
	# Buscar por texto
	for child in parent.get_children():
		if child is Button and child.text == text:
			child.name = name
			return child
	
	# Crear si no existe
	var btn = Button.new()
	btn.name = name
	btn.text = text
	parent.add_child(btn)
	print("✅ Creado botón: ", name)
	return btn

func _find_or_create_label(parent: Node, name: String, text: String):
	# Buscar por nombre
	for child in parent.get_children():
		if child.name == name:
			return child
	
	# Buscar por texto
	for child in parent.get_children():
		if child is Label and child.text == text:
			child.name = name
			return child
	
	# Crear si no existe
	var label = Label.new()
	label.name = name
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(label)
	print("✅ Creado label: ", name)
	return label

func _on_player_connected(peer_id: int):
	print("🆕 Jugador conectado: ", peer_id)
	_update_lobby()

func _on_player_disconnected(peer_id: int):
	print("🚫 Jugador desconectado: ", peer_id)
	_update_lobby()

func _update_lobby():
	if not player_list_container:
		print("❌ player_list_container es null")
		return
	
	# Limpiar UI
	for child in player_list_container.get_children():
		child.queue_free()
	players_ui.clear()
	
	if not GameState:
		return
	
	var players = GameState.players
	
	if players.is_empty():
		var label = Label.new()
		label.text = "⏳ Esperando jugadores..."
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		player_list_container.add_child(label)
		_update_status("⏳ Esperando jugadores...", Color.WHITE)
		return
	
	for peer_id in players:
		var player_data = players[peer_id]
		
		if player_prefab:
			var player_ui = player_prefab.instantiate()
			var name_label = player_ui.get_node_or_null("NameLabel")
			if name_label:
				name_label.text = player_data.name
			
			var ready_check = player_ui.get_node_or_null("ReadyCheck")
			if ready_check:
				ready_check.visible = player_data.ready
				ready_check.modulate = Color.GREEN if player_data.ready else Color.RED
			
			player_list_container.add_child(player_ui)
			players_ui[peer_id] = player_ui
		else:
			# UI simple sin prefab
			var container = HBoxContainer.new()
			var status_label = Label.new()
			status_label.text = "✅" if player_data.ready else "⏳"
			var name_label = Label.new()
			name_label.text = player_data.name
			container.add_child(status_label)
			container.add_child(name_label)
			player_list_container.add_child(container)
			players_ui[peer_id] = container
	
	_update_status("", Color.WHITE)

func _update_status(text: String = "", color: Color = Color.WHITE):
	# Buscar StatusLabel
	var status_label = null
	for child in get_tree().get_nodes_in_group("labels"):
		if child is Label:
			status_label = child
			break
	
	if not status_label:
		# Buscar en toda la escena
		status_label = _find_node_by_name("StatusLabel")
	
	if not status_label:
		print("⚠️ StatusLabel no encontrado")
		return
	
	if not GameState:
		status_label.text = "❌ Error de conexión"
		status_label.modulate = Color.RED
		return
	
	var players = GameState.players
	var players_count = players.size()
	var ready_count = 0
	for player in players.values():
		if player.ready:
			ready_count += 1
	
	if text != "":
		status_label.text = text
		status_label.modulate = color
		return
	
	if players_count == 0:
		status_label.text = "⏳ Esperando jugadores..."
		status_label.modulate = Color.WHITE
	elif ready_count == players_count and players_count >= 2:
		status_label.text = "✅ ¡Todos listos!"
		status_label.modulate = Color.GREEN
	else:
		status_label.text = "👥 %d/%d jugadores listos" % [ready_count, players_count]
		status_label.modulate = Color.YELLOW if ready_count > 0 else Color.WHITE

func _find_node_by_name(name: String):
	# Buscar en toda la escena recursivamente
	return _search_node(self, name)

func _search_node(node: Node, name: String):
	if node.name == name:
		return node
	for child in node.get_children():
		var found = _search_node(child, name)
		if found:
			return found
	return null

func _on_ready_button_pressed():
	is_ready = !is_ready
	
	# Buscar el botón ReadyButton
	var ready_btn = _find_node_by_name("ReadyButton")
	if ready_btn:
		ready_btn.text = "✅ Listo!" if is_ready else "❌ No listo"
	
	if NetworkManager:
		_set_ready.rpc(is_ready)

@rpc("any_peer", "call_local")
func _set_ready(ready: bool):
	if not GameState:
		return
	var sender = multiplayer.get_remote_sender_id()
	GameState.set_ready(sender, ready)
	
	if multiplayer.is_server() and GameState.all_ready():
		_start_game.rpc()

@rpc("call_local")
func _start_game():
	print("🎮 Iniciando partida!")
	if GameState:
		get_tree().change_scene_to_file(GameState.current_level)

func _on_start_button_pressed():
	if multiplayer.is_server():
		_start_game.rpc()

func _on_exit_button_pressed():
	if NetworkManager:
		NetworkManager.disconnect_game()
	get_tree().change_scene_to_file("res://Escenas/MainMenu.tscn")
