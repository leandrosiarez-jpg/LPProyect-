extends Node

signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal connection_succeeded()
signal connection_failed()

var peer = ENetMultiplayerPeer.new()
var game_port: int = 4242
var max_players: int = 4
var is_host: bool = false
var player_name: String = ""

func _ready():
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	print("✅ NetworkManager inicializado")

func create_game(player_name_input: String = "Host"):
	player_name = player_name_input
	peer.create_server(game_port, max_players)
	multiplayer.multiplayer_peer = peer
	is_host = true
	print("✅ Servidor creado")
	
	# Registrar al host inmediatamente
	GameState.players[1] = {
		"name": player_name,
		"score": 0,
		"ready": false
	}
	GameState.players_updated.emit()
	player_connected.emit(1)

func join_game(ip: String, player_name_input: String = "Player"):
	player_name = player_name_input
	peer.create_client(ip, game_port)
	multiplayer.multiplayer_peer = peer
	is_host = false
	print("✅ Conectando a ", ip)

func _on_peer_connected(peer_id: int):
	print("👤 Jugador ", peer_id, " conectado")
	player_connected.emit(peer_id)

func _on_peer_disconnected(peer_id: int):
	print("👋 Jugador ", peer_id, " desconectado")
	GameState.players.erase(peer_id)
	player_disconnected.emit(peer_id)

func _on_connected_to_server():
	print("✅ Conectado al servidor")
	connection_succeeded.emit()
	# Registrar este cliente en el servidor
	var my_id = multiplayer.get_unique_id()
	_register_player.rpc_id(1, player_name, my_id)

func _on_connection_failed():
	print("❌ Error de conexión")
	connection_failed.emit()

@rpc("any_peer", "call_local")
func _register_player(name: String, peer_id: int):
	if not multiplayer.is_server():
		return
	GameState.players[peer_id] = {
		"name": name,
		"score": 0,
		"ready": false
	}
	print("📝 Registrado: ", name, " (ID: ", peer_id, ")")
	GameState.players_updated.emit()

func disconnect_game():
	if peer:
		peer.close()
	multiplayer.multiplayer_peer = null
	is_host = false
	GameState.players.clear()
