extends Control


func _on_server_pressed() -> void:
	HighLevelNetworkHandler.start_server()

func _on_cliente_pressed() -> void:
	HighLevelNetworkHandler.start_client()
