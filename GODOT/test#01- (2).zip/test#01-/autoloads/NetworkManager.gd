extends Node

signal game_created
signal game_joined

signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal connection_succeeded()
signal connection_failed()

var peer = ENetMultiplayerPeer.new()
var game_port: int = 4242
var max_players: int = 2
var is_host: bool = false
# Carga con path absoluto desde la raíz del proyecto
var player_scene: PackedScene = preload("res://Escenas/Player.tscn")  # O "res://scenes/Player.tscn"
var player_name: String = ""

func _ready():
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	print("✅ NetworkManager inicializado")
	
	# Verificar que la escena se cargó correctamente
	if not player_scene:
		push_error("❌ No se pudo cargar Player.tscn. Verifica la ruta del archivo.")

func create_game(player_name_input: String = "Host"):
	player_name = player_name_input
	peer.create_server(game_port, max_players)
	multiplayer.multiplayer_peer = peer
	is_host = true
	print("✅ Servidor creado")
	game_created.emit()
	
	# Registrar al host inmediatamente
	if not GameState.players.has(1):
		GameState.players[1] = {
			"name": player_name,
			"score": 0,
			"ready": false
		}
		GameState.players_updated.emit()
	player_connected.emit(1)
	
	# Spawnear al host local
	_spawn_player(1)

func join_game(ip: String, player_name_input: String = "Player"):
	player_name = player_name_input
	peer.create_client(ip, game_port)
	multiplayer.multiplayer_peer = peer
	is_host = false
	print("✅ Conectando a ", ip)
	game_joined.emit()

func _on_peer_connected(peer_id: int):
	print("👤 Jugador ", peer_id, " conectado")
	player_connected.emit(peer_id)
	if is_host:
		_spawn_player.rpc(peer_id)

func _on_peer_disconnected(peer_id: int):
	print("👋 Jugador ", peer_id, " desconectado")
	GameState.players.erase(peer_id)
	player_disconnected.emit(peer_id)
	
	if multiplayer.is_server():
		_remove_player.rpc(peer_id)

@rpc("call_local", "any_peer")
func _spawn_player(peer_id: int):
	# Verificar que la escena existe antes de instanciar
	if not player_scene:
		push_error("❌ player_scene no está cargado")
		return
	
	var player = player_scene.instantiate()
	if not player:
		push_error("❌ No se pudo instanciar Player.tscn")
		return
		
	player.name = str(peer_id)
	player.set_multiplayer_authority(peer_id)
	
	# Posiciones para 3D o 2D según tu proyecto
	if peer_id == 1:
		player.global_position = Vector3(100, 0, 300)  # Usar Vector2 si es 2D
	else:  # Invitado
		player.global_position = Vector3(700, 0, 300)  # Usar Vector2 si es 2D
	
	add_child(player)
	print("like jugador ", peer_id, " spawneando en la posi ", player.global_position)

@rpc("call_local", "any_peer")
func _remove_player(peer_id: int):
	var player = get_node_or_null(str(peer_id))
	if player:
		player.queue_free()
		print("player ", peer_id, " eliminado")

func _on_connected_to_server():
	print("✅ Conectado al servidor")
	connection_succeeded.emit()
	# Registrar este cliente en el servidor
	var my_id = multiplayer.get_unique_id()
	_register_player.rpc_id(1, player_name, my_id)

func _on_connection_failed():
	print("❌ Error de conexión")
	connection_failed.emit()

@rpc("any_peer", "call_local")
func _register_player(name: String, peer_id: int):
	if not multiplayer.is_server():
		return
	GameState.players[peer_id] = {
		"name": name,
		"score": 0,
		"ready": false
	}
	print("📝 Registrado: ", name, " (ID: ", peer_id, ")")
	GameState.players_updated.emit()

func disconnect_game():
	if peer:
		peer.close()
	multiplayer.multiplayer_peer = null
	is_host = false
	GameState.players.clear()
