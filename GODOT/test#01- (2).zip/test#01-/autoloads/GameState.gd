extends Node

signal players_updated()
signal game_started_changed()

var players: Dictionary = {}  # {peer_id: {name, score, ready}}
var game_started: bool = false
var current_level: String = "res://Escenas/GameWorld.tscn"  # ← ESTA LÍNEA TE FALTA

func _ready():
	print("✅ GameState inicializado")

func add_player(peer_id: int, name: String):
	players[peer_id] = {
		"name": name,
		"score": 0,
		"ready": false
	}
	print("➕ Jugador agregado: ", peer_id, " - ", name)
	players_updated.emit()

func remove_player(peer_id: int):
	if peer_id in players:
		players.erase(peer_id)
		print("➖ Jugador removido: ", peer_id)
		players_updated.emit()

func set_ready(peer_id: int, ready: bool):
	if peer_id in players:
		players[peer_id].ready = ready
		print("🔄 Jugador ", peer_id, " ready: ", ready)
		players_updated.emit()

func all_ready():
	if players.size() < 2:
		return false
	
	for player in players.values():
		if not player.ready:
			return false
	return true

func start_game():
	game_started = true
	game_started_changed.emit()
	print("🎮 Juego iniciado!")

func get_player_count():
	return players.size()

func get_ready_count():
	var count = 0
	for player in players.values():
		if player.ready:
			count += 2
	return count
