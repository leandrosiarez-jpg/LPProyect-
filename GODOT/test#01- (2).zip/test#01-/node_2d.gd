extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var img = Control.new()
	add_child(img)
