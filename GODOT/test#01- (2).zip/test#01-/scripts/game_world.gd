extends Node3D

func _ready():
	print("🌍 GameWorld cargado")
	print("📡 Mi ID: ", multiplayer.get_unique_id())
	print("👑 Soy host? ", multiplayer.is_server())
	
	# Esperar un frame para que los datos se sincronicen
	await get_tree().process_frame
	
	# FORZAR registro del host si está vacío
	if multiplayer.is_server() and GameState.players.is_empty():
		print("⚠️ GameState vacío, registrando al host...")
		GameState.players[1] = {
			"name": "Host",
			"score": 0,
			"ready": true
		}
		GameState.players_updated.emit()
	
	# Mostrar todos los jugadores conectados
	var players = GameState.players
	print("👥 Jugadores en partida: ", players.size())
	for peer_id in players:
		print("  - ", players[peer_id].name, " (ID: ", peer_id, ")")
	
	# Si soy el host, spawnear jugadores
	if multiplayer.is_server():
		_spawn_all_players()

func _spawn_all_players():
	print("🎮 Spawneando jugadores...")
	var spawn_points = get_tree().get_nodes_in_group("spawn_points")
	
	for peer_id in GameState.players:
		var player = _create_player(peer_id)
		if spawn_points.size() > 0:
			var index = (peer_id - 1) % spawn_points.size()
			player.global_position = spawn_points[index].global_position
		else:
			player.global_position = Vector3(randf_range(-2, 2), 0.5, randf_range(-2, 2))
		add_child(player)
		print("  ✅ Jugador ", peer_id, " spawneado")

func _create_player(peer_id: int) -> Node3D:
	var player = Node3D.new()
	player.name = str(peer_id)
	
	var mesh = MeshInstance3D.new()
	mesh.mesh = BoxMesh.new()
	
	var color = Color.GREEN if peer_id == 1 else Color.RED
	mesh.material_override = StandardMaterial3D.new()
	mesh.material_override.albedo_color = color
	
	player.add_child(mesh)
	return player
