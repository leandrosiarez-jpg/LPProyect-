extends CharacterBody2D

@export var speed: float = 300.0
@export var sync_interval: float = 0.05

@onready var sprite: Sprite2D = $Sprite2D
var sync_timer: float = 0.0
var input_direction: Vector2 = Vector2.ZERO  # Cambiado a Vector2

func _ready():
	# Asignar color diferente según el jugador
	if is_multiplayer_authority():
		sprite.modulate = Color.GREEN # Mi jugador
		print("mi player (ID: ", multiplayer.get_unique_id(), ")")
	else:
		sprite.modulate = Color.RED # Otro jugador
		print(" Otro Player (ID: ", multiplayer.get_unique_id(), ")")
	
	# Configurar cámara (solo para el jugador local)
	if is_multiplayer_authority():
		var camera = Camera2D.new()
		camera.enabled = true
		add_child(camera)
		print("la camara fue asignada al Player local")

func _physics_process(delta):
	# Solo procesar input si soy el dueño de este nodo
	if is_multiplayer_authority():
		_handle_input(delta)
		_sync_position(delta)

func _handle_input(delta):
	# get_vector necesita 4 argumentos: negative_x, positive_x, negative_y, positive_y
	var input_vector = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	
	# Si hay input, mover
	if input_vector != Vector2.ZERO:
		velocity = input_vector * speed  # Velocidad es Vector2 en CharacterBody2D
	else:
		velocity = Vector2.ZERO
	move_and_slide()

func _sync_position(delta):
	# Sincronizar posición con otros jugadores
	sync_timer += delta
	if sync_timer >= sync_interval:
		sync_timer = 0.0
		_sync_position_rpc.rpc(global_position)

@rpc("any_peer", "call_local")
func _sync_position_rpc(pos: Vector2):  # Cambiado a Vector2
	# Solo actualizar si NO soy el dueño (para evitar conflictos)
	if not is_multiplayer_authority():
		global_position = pos  # global_position es Vector2 en CharacterBody2D
