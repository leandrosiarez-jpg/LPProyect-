extends Control

func _ready():
	$VBoxContainer/CreateButton.pressed.connect(_on_create_pressed)
	$VBoxContainer/JoinButton.pressed.connect(_on_join_pressed)

func _on_create_pressed():
	NetworkManager.create_game("Host")
	get_tree().change_scene_to_file("res://Escenas/Lobby.tscn")

func _on_join_pressed():
	var ip = $VBoxContainer/IPInput.text
	if ip.is_empty():
		ip = "127.0.0.1"
	NetworkManager.join_game(ip, "Invitado")
	# Esperar conexión
	await NetworkManager.connection_succeeded
	get_tree().change_scene_to_file("res://Escenas/Lobby.tscn")
