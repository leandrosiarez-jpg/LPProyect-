extends CharacterBody3D

@export var speed: float = 5.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.002
@export var sprint_multiplier: float = 2.0

var _mouse_captured: bool = false
var sync_timer: float = 0.0
var sync_interval: float = 0.05

# Referencias a los nodos que vamos a crear
var camera: Camera3D
var mesh_instance: MeshInstance3D
var collision_shape: CollisionShape3D

func _ready():
	# 🔧 CONSTRUIR EL PERSONAJE DESDE CÓDIGO
	_build_character()
	
	# Configurar según autoridad
	name = str(multiplayer.get_unique_id())
	
	if is_multiplayer_authority():
		camera.current = true
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
		_mouse_captured = true
		# Mi personaje es VERDE
		if mesh_instance:
			mesh_instance.material_override = StandardMaterial3D.new()
			mesh_instance.material_override.albedo_color = Color.GREEN
	else:
		camera.current = false
		# Los otros jugadores son ROJOS
		if mesh_instance:
			mesh_instance.material_override = StandardMaterial3D.new()
			mesh_instance.material_override.albedo_color = Color.RED

func _build_character():
	# 1. CREAR LA CÁMARA
	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.position = Vector3(0, 1.5, 0)
	add_child(camera)
	
	# 2. CREAR EL MESH (cuerpo)
	mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "MeshInstance3D"
	
	# Crear un mesh de cápsula
	var capsule_mesh = CapsuleMesh.new()
	capsule_mesh.radius = 0.5
	capsule_mesh.height = 1.8
	mesh_instance.mesh = capsule_mesh
	
	# Posicionar el mesh en el suelo
	mesh_instance.position = Vector3(0, 0.9, 0)
	add_child(mesh_instance)
	
	# 3. CREAR LA COLISIÓN
	collision_shape = CollisionShape3D.new()
	collision_shape.name = "CollisionShape3D"
	
	# Crear forma de colisión de cápsula
	var capsule_shape = CapsuleShape3D.new()
	capsule_shape.radius = 0.5
	capsule_shape.height = 1.8
	collision_shape.shape = capsule_shape
	
	# Posicionar la colisión igual que el mesh
	collision_shape.position = Vector3(0, 0.9, 0)
	add_child(collision_shape)
	
	print("✅ Personaje construido desde código")

func _input(event):
	if not is_multiplayer_authority():
		return
	
	if event is InputEventMouseMotion and _mouse_captured:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -1.5, 1.5)
	
	if Input.is_action_just_pressed("ui_cancel"):
		_mouse_captured = !_mouse_captured
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED if _mouse_captured else Input.MOUSE_MODE_VISIBLE)

func _physics_process(delta):
	if not is_multiplayer_authority():
		return
	
	var current_speed = speed
	if Input.is_action_pressed("shift"):
		current_speed *= sprint_multiplier
	
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	
	if direction.length() > 0:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)
	
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_velocity
	
	if not is_on_floor():
		velocity.y -= 9.8 * delta
	
	move_and_slide()
	
	sync_timer += delta
	if sync_timer >= sync_interval:
		sync_timer = 0.0
		sync_position.rpc(position, velocity)

@rpc("authority", "call_local")
func sync_position(pos: Vector3, vel: Vector3):
	position = pos
	velocity = vel
