extends Node3D

@export var player_scene: PackedScene
@export var spawn_points: Array[Node3D]

var players_spawned: Dictionary = {}  # {peer_id: player_node}

func _ready():
	# Conectar señales
	NetworkManager.player_connected.connect(_on_player_connected)
	NetworkManager.player_disconnected.connect(_on_player_disconnected)
	
	# Si soy el host, spawnearme a mí mismo
	if NetworkManager.is_host:
		_spawn_player(1)

func _on_player_connected(peer_id: int):
	# Solo el host spawnear jugadores
	if not multiplayer.is_server():
		return
	_spawn_player(peer_id)

func _on_player_disconnected(peer_id: int):
	_despawn_player(peer_id)

func _spawn_player(peer_id: int):
	if not player_scene:
		print("❌ player_scene no asignado en SpawnManager")
		return
	
	var player = player_scene.instantiate()
	player.name = str(peer_id)
	player.set_multiplayer_authority(peer_id)
	
	# Asignar punto de spawn
	var spawn_index = (peer_id - 1) % spawn_points.size() if spawn_points.size() > 0 else 0
	if spawn_points.size() > 0 and spawn_points[spawn_index]:
		player.global_position = spawn_points[spawn_index].global_position
	else:
		# Posición aleatoria si no hay spawn points
		player.global_position = Vector3(randf_range(-3, 3), 0.5, randf_range(-3, 3))
	
	add_child(player)
	players_spawned[peer_id] = player
	print("🎮 Spawneado jugador ", peer_id)

func _despawn_player(peer_id: int):
	if peer_id in players_spawned:
		var player = players_spawned[peer_id]
		player.queue_free()
		players_spawned.erase(peer_id)
		print("💀 Despawneado jugador ", peer_id)

@rpc("any_peer", "call_local")
func request_spawn():
	if multiplayer.is_server():
		_spawn_player(multiplayer.get_remote_sender_id())
