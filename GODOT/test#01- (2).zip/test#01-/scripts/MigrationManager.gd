# MigrationManager.gd
extends Node

var is_host: bool = false
var pending_migration: bool = false
var new_host_id: int = 0
var game_port: int = 4242  # ⬅️ Declarar aquí la variable
var max_players: int = 4   # ⬅️ También necesitas esta

# Referencia al NetworkManager (opcional, si está en autoload)
@onready var network_manager = get_node("/root/NetworkManager")

func check_host_migration(disconnected_id: int):
	if disconnected_id != 1:
		return  # Solo importa si se fue el Host
	
	print("Host desconectado, iniciando migración...")
	
	# Obtener lista de jugadores activos
	var active_peers = multiplayer.get_peers()
	if active_peers.is_empty():
		print("No hay jugadores, cerrando partida")
		get_tree().quit()
		return
	
	# Elegir nuevo host (el que tenga menor ID)
	new_host_id = active_peers[0]
	for peer in active_peers:
		if peer < new_host_id:
			new_host_id = peer
	
	if multiplayer.get_unique_id() == new_host_id:
		_promote_to_host()
	else:
		_reconnect_to_new_host(new_host_id)

func _promote_to_host():
	print("Promoviendo a Host...")
	var old_peer = multiplayer.multiplayer_peer
	var new_peer = ENetMultiplayerPeer.new()
	
	# Recrear servidor en el mismo puerto
	new_peer.create_server(game_port, max_players)
	multiplayer.multiplayer_peer = new_peer
	
	# Restaurar estado del juego
	_restore_game_state()
	is_host = true
	print("Ahora soy el Host (ID: ", multiplayer.get_unique_id(), ")")

func _restore_game_state():
	# Aquí cargas el estado guardado (posiciones, puntajes, etc.)
	pass

func _reconnect_to_new_host(new_host_id: int):
	print("Reconectando al nuevo Host: ", new_host_id)
	var new_ip = _get_peer_ip(new_host_id)  # Necesitas implementar esto
	# Esperar 1.5 segundos y reconectar
	await get_tree().create_timer(1.5).timeout
	
	# Usar el NetworkManager para reconectar
	if network_manager:
		network_manager.join_game(new_ip)
	else:
		# O hacer la conexión directamente
		var new_peer = ENetMultiplayerPeer.new()
		new_peer.create_client(new_ip, game_port)
		multiplayer.multiplayer_peer = new_peer

func _get_peer_ip(peer_id: int) -> String:
	# ⚠️ IMPORTANTE: En Godot 4, get_peer_address() no existe directamente
	# Necesitas guardar las IPs cuando los jugadores se conectan
	# O usar un sistema de descubrimiento
	
	# Solución temporal: retornar localhost para pruebas
	print("Función _get_peer_ip() necesita implementación real")
	return "127.0.0.1"  # Solo para pruebas en local
